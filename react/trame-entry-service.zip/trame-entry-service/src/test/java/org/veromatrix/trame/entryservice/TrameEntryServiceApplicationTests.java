package org.veromatrix.trame.entryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrameEntryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
